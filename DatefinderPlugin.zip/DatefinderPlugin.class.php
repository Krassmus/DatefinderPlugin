<?php

require_once __DIR__."/lib/Datefinder.php";

class DatefinderPlugin extends StudIPPlugin implements SystemPlugin
{
}